RetrosynServerUrl = 'http://ukwy1355794.bohrium.tech:50001/sse'
RetrosynAgentName = 'retrosyn_agent'

# tool related
PlanVisualizeReactionTool = 'plan_and_visualize_reaction'
GeneratedImagesKey = 'generated_images'
