ReportAgentName = 'report_agent'
ReportAgentOutKey = 'deep_research_report'
