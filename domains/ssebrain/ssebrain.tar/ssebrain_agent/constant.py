SSEBRAIN_AGENT_NAME = 'ssebrain_agent'
SSE_DATABASE_AGENT_NAME = 'sse_database_agent'
SSE_DEEP_RESEARCH_AGENT_NAME = 'sse_deep_research_agent'

Transfer2Agent = 'transfer_to_agent'

LOADING_STATE_KEY = 'loading_state'
LOADING_START = 'loading_start'
LOADING_END = 'loading_end'
LOADING_DESC = 'loading_desc'
LOADING_TITLE = 'loading_title'
