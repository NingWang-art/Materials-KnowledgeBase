SMILESConversionAgentName = 'smiles_conversion_agent'
SMILESConversionServerUrl = 'http://ctoe1357111.bohrium.tech:50002/sse'
SMILESConversionToolCall = 'smiles2image_tool_call'
